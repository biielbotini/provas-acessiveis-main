/* =========================================================
   Provas Acessíveis — lógica compartilhada
   Armazenamento local (localStorage) + utilitários de voz.
   ========================================================= */

const CHAVE_PROVAS = "pa_provas";
const CHAVE_RESULTADOS = "pa_resultados";
const CHAVE_SESSAO_PROF = "pa_professor_logado";

/* ---------- Armazenamento de provas ---------- */

function obterProvas() {
  try {
    const bruto = localStorage.getItem(CHAVE_PROVAS);
    return bruto ? JSON.parse(bruto) : [];
  } catch (e) {
    console.error("Erro ao ler provas:", e);
    return [];
  }
}

function salvarProvas(provas) {
  localStorage.setItem(CHAVE_PROVAS, JSON.stringify(provas));
}

function obterProvaPorId(id) {
  return obterProvas().find((p) => String(p.id) === String(id));
}

function adicionarProva(prova) {
  const provas = obterProvas();
  prova.id = Date.now().toString();
  provas.push(prova);
  salvarProvas(provas);
  return prova.id;
}

function excluirProva(id) {
  const provas = obterProvas().filter((p) => String(p.id) !== String(id));
  salvarProvas(provas);
}

/* ---------- Resultados dos alunos ---------- */

function salvarResultado(resultado) {
  const resultados = obterResultados();
  resultado.data = new Date().toISOString();
  resultados.push(resultado);
  localStorage.setItem(CHAVE_RESULTADOS, JSON.stringify(resultados));
}

function obterResultados() {
  try {
    const bruto = localStorage.getItem(CHAVE_RESULTADOS);
    return bruto ? JSON.parse(bruto) : [];
  } catch (e) {
    return [];
  }
}

function obterResultadosPorProva(provaId) {
  return obterResultados().filter((r) => String(r.provaId) === String(provaId));
}

/* ---------- Sessão do professor ---------- */

function professorEstaLogado() {
  return sessionStorage.getItem(CHAVE_SESSAO_PROF) === "true";
}

function fazerLoginProfessor() {
  sessionStorage.setItem(CHAVE_SESSAO_PROF, "true");
}

function fazerLogoutProfessor() {
  sessionStorage.removeItem(CHAVE_SESSAO_PROF);
}

function exigirLoginProfessor() {
  if (!professorEstaLogado()) {
    window.location.href = "professor-login.html";
  }
}

/* ---------- Voz (Web Speech API) ---------- */

let vozAtual = null;

function falar(texto, aoTerminar) {
  if (!("speechSynthesis" in window)) {
    if (typeof aoTerminar === "function") aoTerminar();
    return;
  }
  window.speechSynthesis.cancel();
  const enunciado = new SpeechSynthesisUtterance(texto);
  enunciado.lang = "pt-BR";
  enunciado.rate = 1;
  if (typeof aoTerminar === "function") {
    enunciado.onend = aoTerminar;
    enunciado.onerror = aoTerminar;
  }
  vozAtual = enunciado;
  window.speechSynthesis.speak(enunciado);
}

function pararFala() {
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
}

function anunciar(texto) {
  // Atualiza uma região aria-live para leitores de tela, além da nossa própria voz
  const regiao = document.getElementById("anuncio-leitor-tela");
  if (regiao) {
    regiao.textContent = "";
    // pequeno atraso para forçar o leitor de tela a reler mesmo com o mesmo texto
    setTimeout(() => { regiao.textContent = texto; }, 50);
  }
}

/* ---------- Utilitário: letra a partir do índice (0 -> A, 1 -> B...) ---------- */
function letraDaOpcao(indice) {
  return String.fromCharCode(65 + indice);
}
